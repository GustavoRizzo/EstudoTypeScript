import { Component } from "../../../node_modules/@angular/core";

@Component({
    selector: 'meu-primeiro-component',
    template: '<p>Meu primeiro componente com Angular2!</p>'
})
export class MeuPrimeiroComponent {}